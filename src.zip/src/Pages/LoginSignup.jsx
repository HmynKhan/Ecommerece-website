import React from 'react'
import './CSS/Loginsingup.css'

const LoginSignup = () => {
  return (
    <div className='loginsignup'>
      <div className="loginsignup-container">
        <h1>Sign Up</h1>
        <div className="loginsignup-fields">
          <input type="text" placeholder='enter your name' name="" id="" />
          <input type="email" placeholder='enter your email' name="" id="" />
          <input type="password" placeholder='enter your password' name="" id="" />
          <button>Continue</button>
          <p className="loginsignup-login">
            Alread have an Account? <span>Login here</span>
          </p>
          <div className="loginsignup-agree">
            <input type="checkbox" name="" id="" />
            <p>By continuing, i agree  to the terms  of use & privacy policy.</p>
          </div>

        </div>
      </div>
    </div>
  )
}

export default LoginSignup